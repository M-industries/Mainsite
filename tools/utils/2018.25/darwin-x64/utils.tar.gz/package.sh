#!/bin/bash
set -e

if [[ $# -lt 2 ]] || [[ $1 == "--help" ]]; then
	echo "usage: 'project.definition' 'deployment' ['output file']"
	echo "e.g.: devenv/output/project.definition deployments/demo image"
	exit
fi

BASEDIR=$(dirname "$0")
SCRIPTDIR=$(cd "$BASEDIR"; pwd)
WORKDIR="$SCRIPTDIR/_ops"

if [[ $# == 3 ]]; then
	OUTPUT=$3
else
	OUTPUT=image
fi


# convert input to absolute paths
PROJDEF="$(cd "$(dirname "$1")"; pwd)/$(basename "$1")"
DEPLOYMENT="$(cd "$(dirname "$2")"; pwd)/$(basename "$2")"
IMAGE="$(cd "$(dirname "$OUTPUT")"; pwd)/$(basename "$OUTPUT")"


# switch to working dir for download and packaging
mkdir -p "$WORKDIR"
cd "$WORKDIR"

# extract version.bin from project.definition
"$SCRIPTDIR/utils/image-extractor" version .version.bin "$PROJDEF"

# download mapping to minor versions and generate a versions.json
curl -s -L -o .phonebook.json "https://alan-platform.com/versions/phonebook.json"
"$SCRIPTDIR/utils/resolve-stable" .version.bin .phonebook.json .versions.json

# fetch only if...
# if it's been a day since you last fetched
# or if the versions.json is missing
# or if we can't diff
# or diff says the versions.json has changed
timestamp=$(date +%y%m%d)
if [[ ! -f .timestamp || $(cat .timestamp) != "${timestamp}" || ! -f versions.json || ! $(which diff) || $(diff .versions.json versions.json) ]]; then
	echo "${timestamp}" > .timestamp
	cp .versions.json versions.json
	"$SCRIPTDIR/utils/fetch" opsenv
fi

# clean up temp files we no longer need
rm .version.bin .phonebook.json .versions.json

# build the image and move it to the output file
./opsenv/platform/deployment-build-environment/tools/buildenvironment-deploy-system opsenv/platform/deployment-build-configuration/package "$PROJDEF" "$DEPLOYMENT"
mv opsenv/output/image "$IMAGE"
