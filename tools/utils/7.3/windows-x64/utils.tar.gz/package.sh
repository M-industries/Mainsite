#!/bin/bash
set -e

if [[ $# -lt 2 ]] || [[ $1 == "--help" ]]; then
	echo "usage: 'project.definition' 'deployment'"
	echo "e.g.: devenv/output/project.definition deployments/demo"
	exit
fi

BASEDIR=$(dirname "$0")
SCRIPTDIR=$(cd "$BASEDIR"; pwd)

## TODO run this in a tempdir
mkdir -p .tmp
cd .tmp

"$SCRIPTDIR/utils/image-extractor" version .version.bin ../"$1"
curl -s -L -o .phonebook.json "https://alan-platform.com/versions/phonebook.json"
"$SCRIPTDIR/utils/resolve-stable" .version.bin .phonebook.json versions.json
rm .version.bin .phonebook.json

"$SCRIPTDIR/utils/fetch" opsenv
./opsenv/platform/deployment-build-environment/tools/buildenvironment-deploy-system opsenv/platform/deployment-build-configuration/package ../"$1" ../"$2"
mv opsenv/output/image ../image

cd ..
rm -rf .tmp
