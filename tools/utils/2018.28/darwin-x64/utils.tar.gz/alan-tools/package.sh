#!/bin/bash
set -e

# Package a project+deployment, resulting in a ready-to-deploy image.
#
# Runs the buildenvironment-deploy-system, which requires an "opsenv" to be
# fetched. "opsenv" has minor versions (i.e. protocol versions). We can use
# the resolve-stable utility with a "phonebook.json" mapping to find the correct
# minor versions. Or a versions.json file can be provided, e.g. for development.
#
# Because fetch is an expensive operation, especially under Windows, we fetch
# only if...
# you haven't fetched before
# it's been a day since you last fetched
# or the versions.json is missing
# or we can't diff
# or diff says the versions.json has changed



if [[ $# -lt 2 || $1 == "--help" ]]; then
	echo "Package the project into a deployment image"
	echo "usage: 'project.definition' 'deployment' [-f 'versions.json'] ['output']"
	echo "e.g.: devenv/output/project.definition deployments/demo demo.image"
	exit
fi

TIMESTAMP=$(date +%y%m%d)
BASEDIR=$(dirname "$0")
SCRIPTDIR=$(cd "$BASEDIR"; pwd)
WORKDIR="$SCRIPTDIR/_ops"

# convert input to absolute paths
PROJDEF="$(cd "$(dirname "$1")"; pwd)/$(basename "$1")"
DEPLOYMENT="$(cd "$(dirname "$2")"; pwd)/$(basename "$2")"

if [[ $# == 3 && $3 != "-f" ]]; then
	OUTPUT=$3
elif [[ $# == 5 ]]; then
	OUTPUT=$5
else
	OUTPUT=$(basename "$DEPLOYMENT").image
fi
OUTPUT="$(cd "$(dirname "$OUTPUT")"; pwd)/$(basename "$OUTPUT")"

if [[ $3 == "-f" ]]; then
	VERSIONS=$4
	VERSIONS="$(cd "$(dirname "$VERSIONS")"; pwd)/$(basename "$VERSIONS")"
fi


# switch to working dir for download and packaging
mkdir -p "$WORKDIR"
cd "$WORKDIR"


if [[ $VERSIONS ]]; then
	# if the versions.json is provided use that
	if [[ ! -f versions.json || ! $(command -v diff) || $(diff "$VERSIONS" versions.json) ]]; then
		cp "$VERSIONS" versions.json
		GOFETCH="True"
	fi
else
	# extract version.bin from project.definition
	"$SCRIPTDIR/image-extractor" version .version.bin "$PROJDEF"

	# download mapping to minor versions and generate a versions.json
	curl -s -L -o .phonebook.json "https://alan-platform.com/versions/phonebook.json"
	"$SCRIPTDIR/resolve-stable" .version.bin .phonebook.json .versions.json

	if [[ ! -f versions.json || ! $(command -v diff) || $(diff .versions.json versions.json) ]]; then
		cp .versions.json versions.json
		GOFETCH="True"
	fi

	# clean up temp files we no longer need
	rm .version.bin .phonebook.json .versions.json
fi


# check the timestamps
if [[ ! -f .timestamp || $(cat .timestamp) != "${TIMESTAMP}" ]];then
	GOFETCH="True"
fi
# first time opsenve fetch, or fetch because reasons
if [[ ! -d opsenv || $GOFETCH == "True" ]];then
	echo "${TIMESTAMP}" > .timestamp
	"$SCRIPTDIR/fetch" opsenv
fi


# build the image and move it to the output file
./opsenv/platform/deployment-build-environment/tools/buildenvironment-deploy-system opsenv/platform/deployment-build-configuration/package "$PROJDEF" "$DEPLOYMENT"
mv opsenv/output/image "$OUTPUT"
